<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Confirmação - Guia Turístico</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e8f5e9;
            padding: 30px;
            text-align: center;
            color: #2e7d32;
        }

        .box {
            background: white;
            display: inline-block;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        h2 {
            margin-bottom: 20px;
        }

        p {
            margin: 5px 0;
        }

        .guia {
            margin-top: 30px;
        }

        .guia img {
            width: 139px;
            border-radius: 50%;
            margin-top: 10px;
        }

        a {
            margin-top: 20px;
            display: inline-block;
            color: #2e7d32;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="box">
        <h2>Serviço contratado com sucesso!</h2>
        <p><strong>Nome:</strong> <?= esc($dados['nome']) ?></p>
        <p><strong>Quantidade:</strong> <?= esc($dados['quantidade']) ?></p>
        <p><strong>Destino:</strong> <?= esc($dados['destino']) ?></p>
        <p><strong>Guia particular:</strong> <?= isset($dados['guia_particular']) ? 'Sim' : 'Não' ?></p>
        <p><strong>Trilha incluída:</strong> <?= isset($dados['trilha']) ? 'Sim' : 'Não' ?></p>

        <div class="guia">
            <h3>Seu guia:</h3>
            <p><strong><?= esc($guia['nome']) ?></strong></p>
            <img src="<?= base_url('images/' . esc($guia['imagem'])) ?>" alt="Guia <?= esc($guia['nome']) ?>">
        </div>

        <a href="<?= site_url('guias') ?>">Voltar</a>
    </div>
</body>
</html>
