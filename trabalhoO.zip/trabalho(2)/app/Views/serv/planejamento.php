<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <title>Planejamento Financeiro</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #e6f0e9;
            color: #2c6e49;
            margin: 0;
            padding: 0 15px 40px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            margin-top: 40px;
            font-size: 2.5rem;
            font-weight: 700;
            text-align: center;
            letter-spacing: 1.2px;
            text-shadow: 0 1px 2px rgba(46, 83, 57, 0.3);
        }

        form {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(46, 83, 57, 0.1);
            padding: 30px 30px 40px;
            max-width: 500px;
            width: 100%;
            margin: 30px 0 0;
        }

        label {
            font-weight: 600;
            margin-bottom: 8px;
            display: block;
            font-size: 1.05rem;
            color: #2f6d36;
        }

        input[type="number"] {
            width: 100%;
            padding: 12px 15px;
            font-size: 1rem;
            border-radius: 6px;
            border: 1.8px solid #a1c997;
            margin-bottom: 25px;
            transition: border-color 0.3s ease;
        }

        input[type="number"]:focus {
            outline: none;
            border-color: #4caf50;
            box-shadow: 0 0 6px #4caf50aa;
        }

        /* Checkboxes container */
        .checkbox-group {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 30px;
            justify-content: space-between;
        }

        .checkbox-item {
            flex: 1 1 48%;
            background: #f4f9f4;
            border-radius: 10px;
            padding: 10px 15px;
            display: flex;
            align-items: center;
            cursor: pointer;
            user-select: none;
            transition: background-color 0.3s ease;
            border: 2px solid transparent;
        }
        .checkbox-item:hover {
            background-color: #def2d8;
        }

        /* Estiliza input checkbox escondido e label personalizado */
        .checkbox-item input[type="checkbox"] {
            appearance: none;
            -webkit-appearance: none;
            width: 22px;
            height: 22px;
            border-radius: 6px;
            border: 2.5px solid #4caf50;
            margin-right: 15px;
            position: relative;
            cursor: pointer;
            transition: background-color 0.25s ease, border-color 0.25s ease;
        }

        .checkbox-item input[type="checkbox"]:checked {
            background-color: #4caf50;
            border-color: #4caf50;
        }

        .checkbox-item input[type="checkbox"]:checked::after {
            content: '✓';
            color: white;
            position: absolute;
            top: 0;
            left: 5px;
            font-size: 18px;
            line-height: 22px;
        }

        /* Texto do label do checkbox */
        .checkbox-item span {
            flex-grow: 1;
            font-weight: 600;
            font-size: 1rem;
            color: #2c6e49;
        }

        button[type="submit"] {
            background-color: #4caf50;
            color: white;
            border: none;
            padding: 15px 0;
            font-size: 1.2rem;
            font-weight: 700;
            border-radius: 10px;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s ease;
            box-shadow: 0 4px 12px rgba(76, 175, 80, 0.4);
        }

        button[type="submit"]:hover {
            background-color: #3a8236;
            box-shadow: 0 6px 16px rgba(58, 130, 54, 0.6);
        }

        h3 {
            text-align: center;
            color: #3a8236;
            font-size: 1.8rem;
            font-weight: 700;
            margin-top: 30px;
            text-shadow: 0 1px 2px #b6d9aa;
        }

        .botao {
            margin: 35px auto 0;
            background-color: #4caf50;
            border: none;
            color: white;
            padding: 12px 18px;
            font-size: 28px;
            border-radius: 12px;
            cursor: pointer;
            display: block;
            box-shadow: 0 4px 10px #4caf50aa;
            transition: background-color 0.3s ease;
            width: 100px;
        }

        .botao:hover {
            background-color: #3a8236;
        }

        @media (max-width: 480px) {
            .checkbox-group {
                flex-direction: column;
            }

            .checkbox-item {
                flex: 1 1 100%;
            }
        }
    </style>
</head>
<body>
    <h2>Planejamento Financeiro</h2>

    <form action="<?= site_url('planejamento/calcular') ?>" method="post">
        <?= csrf_field() ?>

        <label for="quantidade_pessoas">Quantidade de Pessoas:</label>
        <input type="number" name="quantidade_pessoas" id="quantidade_pessoas" min="1" required />

        <div class="checkbox-group">
            <label class="checkbox-item" for="hospedagem">
                <input type="checkbox" name="hospedagem" id="hospedagem" value="1" />
                <span>Hospedagem (R$150 por pessoa/dia)</span>
            </label>

            <label class="checkbox-item" for="trilhas">
                <input type="checkbox" name="trilhas" id="trilhas" value="1" />
                <span>Trilhas (R$70 por pessoa)</span>
            </label>

            <label class="checkbox-item" for="lojas_locais">
                <input type="checkbox" name="lojas_locais" id="lojas_locais" value="1" />
                <span>Visitar Lojas Locais (R$200 por pessoa)</span>
            </label>

            <label class="checkbox-item" for="guia_particular">
                <input type="checkbox" name="guia_particular" id="guia_particular" value="1" />
                <span>Guia Particular (R$200 por pessoa)</span>
            </label>
        </div>

        <button type="submit">Calcular</button>
    </form>

    <?php if (isset($total)): ?>
        <h3>Total Estimado: R$ <?= number_format($total, 2, ',', '.') ?></h3>
    <?php endif; ?>

    <button class="botao" onclick="location.href='<?= site_url('home') ?>'">⤌</button>
</body>
</html>
