<!DOCTYPE html>
<html lang="pt-BR">

<head>


  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Sustentavelmente</title>
  <link rel="shortcut icon" href="<?= base_url('favicon-novo.ico?v=1') ?>" type="image/x-icon">






  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding-top: 70px; 
      background-color: #e6f3ea;
      color: #2e5339;
    }

    .navbar {
      background-color: #2f6d36; 
      box-shadow: 0 2px 8px rgb(47 109 54 / 0.3);
    }

    .navbar-brand {
      color: #d1f0c4;
      font-weight: 700;
      font-size: 28px;
      letter-spacing: 1px;
      transition: color 0.3s ease;
    }

    .navbar-brand:hover {
      color: #a5d6a7;
      text-decoration: none;
    }

    .nav-link {
      color: #d1f0c4 !important;
      font-weight: 500;
      transition: background-color 0.25s ease, color 0.25s ease;
      border-radius: 6px;
      padding: 8px 14px !important;
    }

    .nav-link:hover {
      background-color: #a5d6a7;
      color: #1b3a1a !important;
      text-decoration: none;
    }

  
    .accordion-button {
      background-color: transparent !important;
      color: #d1f0c4 !important;
      font-weight: 600;
      border: none;
      padding: 0.375rem 1rem;
      font-size: 1rem;
      border-radius: 6px;
      transition: background-color 0.25s ease;
    }

    .accordion-button:hover {
      background-color: #a5d6a7 !important;
      color: #1b3a1a !important;
      text-decoration: none;
    }

    .accordion-button:focus {
      box-shadow: none !important;
    }

    .accordion-button::before {
     
      font-size: 16px;
      margin-right: 8px;
      color: #d1f0c4;
      transition: transform 0.3s ease;
    }

    .accordion-button:not(.collapsed)::before {
      transform: rotate(90deg);
    }

    .accordion-collapse {
      background-color: #a5d6a7;
      border-radius: 0 0 8px 8px;
    }

    .accordion-body {
      padding: 0.25rem 1.5rem;
      background-color: #cce6c8;
      border-radius: 0 0 8px 8px;
      display: flex;
      flex-direction: column;
    }

    .menu-subitem {
      color: #2e5339;
      padding: 8px 12px;
      cursor: pointer;
      border-radius: 5px;
      transition: background-color 0.25s ease;
      font-weight: 600;
      margin-bottom: 6px;
    }

    .menu-subitem:hover {
      background-color: #87bb6f;
      color: #153b07;
      text-decoration: none;
    }

    .menu-subitem:last-child {
      margin-bottom: 0;
    }

    
    .navbar-toggler {
      border-color: #a5d6a7;
    }

    .navbar-toggler-icon {
      background-image: url("data:image/svg+xml;charset=utf8,%3Csvg viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath stroke='%23a5d6a7' stroke-width='3' stroke-linecap='round' stroke-miterlimit='10' d='M4 7h22M4 15h22M4 23h22'/%3E%3C/svg%3E");
    }

   
    .nav-item.dropdown > .accordion {
      width: 100%;
    }

  </style>
</head>
<body>

  <nav class="navbar navbar-expand-lg fixed-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="<?= site_url('/') ?>">Sustentavelmente</a>
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarMenu"
        aria-controls="navbarMenu"
        aria-expanded="false"
        aria-label="Alternar navegação"
      >
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarMenu">
        <ul class="navbar-nav ms-auto align-items-center gap-2">

          <li class="nav-item">
            <a class="nav-link" href="<?= site_url('perfil') ?>">Conta</a>
          </li>

    
        
          <li class="nav-item dropdown">
            <div class="accordion" id="accordionAgendar" style="background: transparent;">
              <div class="accordion-item bg-transparent border-0">
                <h2 class="accordion-header" id="headingAgendar">
                  <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseAgendar"
                    aria-expanded="false"
                    aria-controls="collapseAgendar"
                  >
                    Agendar
                  </button>
                </h2>
                <div
                  id="collapseAgendar"
                  class="accordion-collapse collapse"
                  aria-labelledby="headingAgendar"
                  data-bs-parent="#accordionAgendar"
                >
                  <div class="accordion-body p-2 d-flex flex-column">
                    <div class="menu-subitem" onclick="location.href='<?= site_url('hospedagem') ?>'">
                      Hospedagem
                    </div>
                    <div class="menu-subitem" onclick="location.href='<?= site_url('trilhas') ?>'">
                      Trilhas
                    </div>
                    <div class="menu-subitem" onclick="location.href='<?= site_url('guias') ?>'">
                      Guias
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?= site_url('planejamento') ?>">Planejamento Financeiro</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>



  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
