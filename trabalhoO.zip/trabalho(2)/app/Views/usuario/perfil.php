<!DOCTYPE html>
<html>
<head>
    <title>Perfil do Usuário</title>
    <style>
        

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #e8f5e9;
            color: #2e5339;
            margin: 0;
            padding: 40px 20px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            border-radius: 12px;
            padding: 30px 40px;
            box-shadow: 0 4px 10px rgba(46, 83, 57, 0.2);
            text-align: left;
        }

        img.profile-photo {
            display: block;
            margin-bottom: 25px;
            border-radius: 50%;
            width: 160px;
            height: 160px;
            object-fit: cover;
            border: 4px solid #4caf50;
        }

        h1 {
            margin-top: 0;
            margin-bottom: 20px;
            font-size: 2.4rem;
            font-weight: 700;
            color: #388e3c;
        }

        p {
            font-size: 1.1rem;
            line-height: 1.6;
            margin: 8px 0;
        }

        strong {
            color: #2e5339;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: 600;
            font-size: 1rem;
            color: #2e5339;
        }

        input[type="text"],
        input[type="email"],
        input[type="tel"],
        input[type="file"] {
            width: 100%;
            padding: 10px 12px;
            font-size: 1rem;
            border: 2px solid #4caf50;
            border-radius: 8px;
            margin-top: 6px;
            box-sizing: border-box;
        }

        input[type="file"] {
            padding: 6px 0;
            cursor: pointer;
            color: #2e5339;
        }

        button, input[type="submit"] {
            background-color: #4caf50;
            border: none;
            color: white;
            padding: 14px 28px;
            font-size: 1.1rem;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-top: 20px;
            display: inline-block;
        }

        button:hover, input[type="submit"]:hover {
            background-color: #388e3c;
        }

        .welcome-msg {
            font-size: 1.25rem;
            margin-bottom: 30px;
            font-weight: 600;
            color: #2e5339;
        }

        .alert {
            padding: 12px 20px;
            margin-bottom: 20px;
            border-radius: 8px;
        }

        .alert-success {
            background-color: #d0f0c0;
            color: #2e5339;
            border: 1px solid #4caf50;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .botao {
            width: 90px;
            height: 80px;
            margin-left: 50px;
            color: white;
            background-color:rgb(74, 143, 102);
            font-size: 39px;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (session()->get('success')): ?>
            <div class="alert alert-success"><?= session()->get('success') ?></div>
        <?php endif; ?>

        <?php if (session()->get('error')): ?>
            <div class="alert alert-error"><?= session()->get('error') ?></div>
        <?php endif; ?>

        <?php if (isset($usuario) && $usuario): ?>
            
            <?php if (!empty($usuario['foto'])): ?>
                <img class="profile-photo" src="<?= base_url('uploads/' . esc($usuario['foto'])) ?>" alt="Foto de Perfil">
            <?php endif; ?>

            <p class="welcome-msg">Bem-vindo, <?= esc($usuario['nome']) ?>!</p>

            <h1>Perfil</h1>

            <!-- Formulário de edição -->
            <form action="<?= base_url('usuario/atualizarPerfil') ?>" method="post" enctype="multipart/form-data">

                <label for="nome">Nome:</label>
                <input type="text" name="nome" id="nome" value="<?= esc($usuario['nome']) ?>" required>

                <label for="email">Email:</label>
                <input type="email" name="email" id="email" value="<?= esc($usuario['email']) ?>" required>

                <label for="telefone">Telefone:</label>
                <input type="tel" name="telefone" id="telefone" value="<?= esc($usuario['telefone']) ?>">

                <label for="foto">Atualize sua foto de perfil:</label>
                <input type="file" name="foto" id="foto" accept="image/*">

                <input type="submit" value="Salvar Alterações">

            </form>

        <?php else: ?>
            <p>Usuário não encontrado.</p>
        <?php endif; ?>
    </div>

    <button class="botao" onclick="location.href='<?= site_url('home') ?>'">⤌</button> 
</body>
</html>
