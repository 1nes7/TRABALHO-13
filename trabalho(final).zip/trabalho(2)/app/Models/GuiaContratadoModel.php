<?php

namespace App\Models;

use CodeIgniter\Model;

class GuiaContratadoModel extends Model
{
    protected $table = 'guias_contratados';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nome', 'quantidade', 'destino', 'guia_particular', 'trilha'];
  
}
