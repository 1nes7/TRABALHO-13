<?php

namespace App\Models;

use CodeIgniter\Model;

class TrilhaModel extends Model
{
    public function getTrilhas()
    {
        return [
            ['nome' => 'Trilha da Pedra Furada', 'pais' => 'Brasil', 'cidade' => 'Jericoacoara', 'descricao' => 'Uma trilha leve com vistas incríveis da costa nordestina.'],
            ['nome' => 'Trilha Inca', 'pais' => 'Peru', 'cidade' => 'Cusco', 'descricao' => 'Caminho histórico até Machu Picchu com foco em preservação ambiental.'],
            ['nome' => 'Sendero Fitz Roy', 'pais' => 'Argentina', 'cidade' => 'El Chaltén', 'descricao' => 'Trilha na Patagônia com paisagens montanhosas e natureza intocada.'],
            ['nome' => 'Trilha da Floresta Atlântica', 'pais' => 'Brasil', 'cidade' => 'Ilhabela', 'descricao' => 'Imersão ecológica na rica biodiversidade da mata atlântica.'],
        ];
    }

    public function getPaises()
    {
        return ['Brasil', 'Peru', 'Argentina'];
    }

    public function getCidadesPorPais($pais)
    {
        $todas = [
            'Brasil' => ['Jericoacoara', 'Ilhabela'],
            'Peru' => ['Cusco'],
            'Argentina' => ['El Chaltén'],
        ];
        return $todas[$pais] ?? [];
    }
}
