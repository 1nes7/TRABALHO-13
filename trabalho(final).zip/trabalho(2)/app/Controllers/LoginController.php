<?php

namespace App\Controllers;

use App\Models\LoginModel;
use CodeIgniter\Controller;

class LoginController extends Controller
{
    public function index()
    {
        return view('serv/login');
    }

public function processar()
{
    $email = $this->request->getPost('email');
    $senha = $this->request->getPost('senha_hash'); 

    $model = new LoginModel();
    $usuario = $model->where('email', $email)->first();

    if ($usuario && password_verify($senha, $usuario['senha_hash'])) {
        session()->set('usuario', $usuario);
        return redirect()->to(site_url('home')); // rota
    } else {
        return redirect()->back()->with('error', 'Credenciais inválidas.');
    }
}


    public function logout()
    {
        session()->destroy();
        return redirect()->to(site_url('login'));
    }
}
