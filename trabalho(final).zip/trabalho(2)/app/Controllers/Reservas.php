<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\ReservaModel;



class Reservas extends Controller
{
    public function index()
    {
      
        return view('serv/hospedagemform'); 
    }
      public function salvar()
    {
        $model = new ReservaModel();

        $data = [
            'hotel'      => $this->request->getPost('hotel'),
            'nome'       => $this->request->getPost('nome'),
            'quantidade' => $this->request->getPost('quantidade'),
            'preco'      => $this->request->getPost('preco'),
        ];

        $model->insert($data);

        return view('serv/confirmado', ['reserva' => $data]);
    }

}