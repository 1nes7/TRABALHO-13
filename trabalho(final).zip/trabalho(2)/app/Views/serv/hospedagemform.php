<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" href="<?= base_url('favicon-novo.ico?v=1') ?>" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reserva com Pagamento</title>

    <style>
        
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }

        form, .pagamento {
            max-width: 500px;
            margin: 40px auto;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
            color: #2e7d32;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            font-size: 16px;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #cccccc;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 15px;
        }

        input:focus {
            outline: none;
            border-color: #4caf50;
            box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.2);
        }

        button {
            width: 100%;
            padding: 14px;
            background-color: #2e7d32;
            color: #ffffff;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        button:hover {
            background-color: #1b5e20;
        }

        .pagamento {
            display: none;
            text-align: center;
        }

        .pagamento h3 {
            margin-bottom: 20px;
        }

        .botao {
            width: 90px;
            height: 80px;
            margin-left: 50px;
            color: white;
            background-color:rgb(74, 143, 102);
            font-size: 39px;
        }
    </style>
</head>
<body>

    
    <form id="formReserva">
        <label for="hotel"><strong>Nome do Hotel:</strong></label>
        <input type="text" id="hotel" name="hotel" value="EcoHotel Verde Vida" readonly>

        <label for="nome"><strong>Seu Nome:</strong></label>
        <input type="text" id="nome" name="nome" required>

        <label for="quantidade"><strong>Quantidade de Pessoas:</strong></label>
        <input type="number" id="quantidade" name="quantidade" min="1" required>

        <label for="preco"><strong>Preço por Pessoa:</strong></label>
<input type="text" id="preco" name="preco" value="150" readonly>

        <button type="button" onclick="mostrarPagamento()">Reservar</button>
    </form>

   
<div class="pagamento" id="pagamentoDiv">
    <h3>Confirmação de Pagamento</h3>
    <p><strong>Nome:</strong> <span id="resumoNome"></span></p>
    <p><strong>Hotel:</strong> EcoHotel Verde Vida</p>
    <p><strong>Quantidade:</strong> <span id="resumoQtd"></span></p>
    <p><strong>Total:</strong> R$ <span id="resumoTotal"></span></p>

    <
    <label for="formaPagamento"><strong>Forma de Pagamento:</strong></label>
    <select id="formaPagamento" onchange="mostrarFormaPagamento()">
        <option value="">Selecione</option>
        <option value="pix">Pix</option>
        <option value="cartao">Cartão</option>
        <option value="boleto">Boleto</option>
    </select>


    <div id="pagamentoPix" style="display: none; margin-top: 20px;">
        <p><strong>Escaneie o QR Code:</strong></p>
        <img src="https://api.qrserver.com/v1/create-qr-code/?data=ChavePix12345&size=150x150" alt="QR Code Pix">
        <p><strong>Chave Pix:</strong> ChavePix12345</p>
    </div>

  
    <div id="pagamentoCartao" style="display: none; margin-top: 20px;">
        <label for="numeroCartao">Número do Cartão:</label>
        <input type="text" id="numeroCartao" maxlength="16" placeholder="1234 5678 9012 3456">

        <label for="validade">Validade:</label>
        <input type="text" id="validade" placeholder="MM/AA">

        <label for="cvv">CVV:</label>
        <input type="text" id="cvv" maxlength="3" placeholder="123">
    </div>

    
    <div id="pagamentoBoleto" style="display: none; margin-top: 20px;">
        <p><strong>Boleto gerado:</strong></p>
        <a href="#" onclick="gerarBoleto()">Clique aqui para baixar o boleto</a>
        <p id="linkBoleto" style="color: green;"></p>
    </div>

    <button onclick="enviarFormulario()">Confirmar Pagamento</button>
</div>


    <script>
        function mostrarPagamento() {
            const nome = document.getElementById('nome').value;
            const qtd = parseInt(document.getElementById('quantidade').value);
            const preco = parseFloat(document.getElementById('preco').value);

            if (!nome || !qtd || qtd < 1) {
                alert('Preencha os campos corretamente.');
                return;
            }

            
            document.getElementById('resumoNome').textContent = nome;
            document.getElementById('resumoQtd').textContent = qtd;
            document.getElementById('resumoTotal').textContent = (qtd * preco).toFixed(2);

         
            document.getElementById('formReserva').style.display = 'none';
            document.getElementById('pagamentoDiv').style.display = 'block';
        }

        function enviarFormulario() {
           
            document.getElementById('formReserva').submit();
        }

         function mostrarPagamento() {
        const nome = document.getElementById('nome').value;
        const qtd = parseInt(document.getElementById('quantidade').value);
        const preco = parseFloat(document.getElementById('preco').value);

        if (!nome || !qtd || qtd < 1) {
            alert('Preencha os campos corretamente.');
            return;
        }

        document.getElementById('resumoNome').textContent = nome;
        document.getElementById('resumoQtd').textContent = qtd;
        document.getElementById('resumoTotal').textContent = (qtd * preco).toFixed(2);

        document.getElementById('formReserva').style.display = 'none';
        document.getElementById('pagamentoDiv').style.display = 'block';
    }

    function mostrarFormaPagamento() {
        const forma = document.getElementById('formaPagamento').value;

        document.getElementById('pagamentoPix').style.display = 'none';
        document.getElementById('pagamentoCartao').style.display = 'none';
        document.getElementById('pagamentoBoleto').style.display = 'none';

        if (forma === 'pix') {
            document.getElementById('pagamentoPix').style.display = 'block';
        } else if (forma === 'cartao') {
            document.getElementById('pagamentoCartao').style.display = 'block';
        } else if (forma === 'boleto') {
            document.getElementById('pagamentoBoleto').style.display = 'block';
        }
    }

    function gerarBoleto() {
     
        const codigoBoleto = '34191.79001 01043.510047 91020.150008 5 85070000010000';
        document.getElementById('linkBoleto').textContent = 'Código do Boleto: ' + codigoBoleto;
    }

    function enviarFormulario() {
        const forma = document.getElementById('formaPagamento').value;
        if (!forma) {
            alert("Escolha uma forma de pagamento.");
            return;
        }

        alert("Pagamento confirmado via " + forma.toUpperCase() + "!");
        
    }
    </script>

<button class="botao" onclick="location.href='<?= site_url('home') ?>'">⤌</button> 

</body>
</html>
