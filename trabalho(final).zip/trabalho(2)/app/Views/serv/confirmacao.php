<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" href="<?= base_url('favicon-novo.ico?v=1') ?>" type="image/x-icon">
    <title>Confirmação de Agendamento</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4fdf4;
            color: #2e7d32;
            padding: 30px;
            text-align: center;
        }

        .box {
            background: white;
            padding: 30px;
            max-width: 500px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .box h2 {
            margin-bottom: 20px;
        }

        .box p {
            margin: 10px 0;
        }

        .guia {
            margin-top: 30px;
        }

        .guia img {
            width: 200px;
            border-radius: 50%;
            margin-top: 10px;
        }

        .botao {
            width: 90px;
            height: 80px;
            margin-center: 50px; 
            color: white;
            background-color:rgb(74, 143, 102);
            font-size: 39px;
        }
    </style>
</head>
<body>
    <div class="box">
        <h2>Agendamento Confirmado!</h2>
        <p><strong>Lugar:</strong> <?= esc($lugar) ?></p>
        <p><strong>Nome:</strong> <?= esc($nome) ?></p>
        <p><strong>Data:</strong> <?= esc($data) ?></p>
        <p><strong>Quantidade de pessoas:</strong> <?= esc($quantidade) ?></p>

        <div class="guia">
            <h3>Seu guia:</h3>
            <p><strong><?= esc($guia['nome']) ?></strong></p>
            <img src="<?= base_url('images/' . esc($guia['imagem'])) ?>" alt="Guia <?= esc($guia['nome']) ?>">
        </div>
    </div>
     <button class="botao" onclick="location.href='<?= site_url('home') ?>'">⤌</button> 
</body>
</html>
