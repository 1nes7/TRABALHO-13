<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" href="<?= base_url('favicon-novo.ico?v=1') ?>" type="image/x-icon">
    <title>Guias Turísticos - Sustentavelmente</title>
    <style>
      
        body {
            font-family: Arial, sans-serif;
            background-color: #f1f7f1;
            padding: 30px;
            color: #2e7d32;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

        form {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        label {
            font-weight: bold;
            display: block;
            margin-top: 15px;
        }

        input[type="text"],
        input[type="number"],
        select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }

        .checkbox-group {
            margin-top: 10px;
        }

        .checkbox-group label {
            font-weight: normal;
            display: flex;
            align-items: center;
        }

        .checkbox-group input {
            margin-right: 10px;
        }

        button {
            margin-top: 25px;
            padding: 12px 20px;
            background-color: #2e7d32;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            width: 100%;
        }

        button:hover {
            background-color: #1b5e20;
        }

        .pagamento {
            display: none;
            margin-top: 20px;
        }

        .pagamento div {
            margin-bottom: 20px;
        }

        .botao {
            width: 90px;
            height: 80px;
            margin-left: 50px;
            color: white;
            background-color: rgb(74, 143, 102);
            font-size: 39px;
        }
    </style>
</head>
<body>

    <h1>Contratar Guia Turístico</h1>

    <form id="formReserva">
        <label for="nome">Seu nome:</label>
        <input type="text" name="nome" id="nome" required>

        <label for="quantidade">Quantidade de pessoas:</label>
        <input type="number" name="quantidade" id="quantidade" min="1" required>

        <label for="destino">Destino:</label>
        <select name="destino" id="destino" required>
            <option value="">Selecione um destino</option>
            <option value="Chapada dos Veadeiros">Chapada dos Veadeiros</option>
            <option value="Serra da Canastra">Serra da Canastra</option>
            <option value="Fernando de Noronha">Fernando de Noronha</option>
            <option value="Trilha Verde Encantada">Trilha Verde Encantada</option>
            <option value="Vale das Águas Claras">Vale das Águas Claras</option>
            <option value="Montanhas da Liberdade">Montanhas da Liberdade</option>
        </select>

        <div class="checkbox-group">
            <label>
                <input type="checkbox" name="guia_particular" value="Sim">
                Guia particular (vai lhe guiar mesmo depois das trilhas)
            </label>
        </div>

        <div class="checkbox-group">
            <label>
                <input type="checkbox" name="trilha" value="Sim">
                Inclui trilha guiada
            </label>
        </div>

        <button type="button" onclick="mostrarPagamento()">Contratar serviço</button>
    </form>

    <div class="pagamento" id="pagamentoDiv">
        <h3>Confirmação de Pagamento</h3>
        <p><strong>Nome:</strong> <span id="resumoNome"></span></p>
        <p><strong>Destino:</strong> <span id="resumoDestino"></span></p>
        <p><strong>Quantidade:</strong> <span id="resumoQtd"></span></p>
        <p><strong>Total:</strong> R$ <span id="resumoTotal"></span></p>

        <label for="formaPagamento"><strong>Forma de Pagamento:</strong></label>
        <select id="formaPagamento" onchange="mostrarFormaPagamento()">
            <option value="">Selecione</option>
            <option value="pix">Pix</option>
            <option value="cartao">Cartão de Crédito</option>
            <option value="boleto">Boleto Bancário</option>
        </select>

        <div id="pagamentoPix" style="display: none;">
            <p><strong>Chave Pix:</strong> chavepix@dominio.com</p>
            <p><strong>Escaneie o QR Code:</strong></p>
            <img src="https://api.qrserver.com/v1/create-qr-code/?data=chavepix@dominio.com&size=150x150" alt="QR Code Pix">
        </div>

        <div id="pagamentoCartao" style="display: none;">
            <label for="numeroCartao">Número do Cartão:</label>
            <input type="text" id="numeroCartao" placeholder="1234 5678 9012 3456" maxlength="16">

            <label for="validade">Validade:</label>
            <input type="text" id="validade" placeholder="MM/AA">

            <label for="cvv">CVV:</label>
            <input type="text" id="cvv" maxlength="3" placeholder="123">
        </div>

        <div id="pagamentoBoleto" style="display: none;">
            <p><strong>Boleto gerado:</strong></p>
            <a href="#" onclick="gerarBoleto()">Clique aqui para baixar o boleto</a>
            <p id="linkBoleto" style="color: green;"></p>
        </div>

        <button onclick="enviarFormulario()">Confirmar Pagamento</button>
    </div>

    <script>
        function mostrarPagamento() {
            const nome = document.getElementById('nome').value;
            const qtd = parseInt(document.getElementById('quantidade').value);
            const destino = document.getElementById('destino').value;

            if (!nome || !qtd || qtd < 1 || !destino) {
                alert('Preencha os campos corretamente.');
                return;
            }

            const preco = 200; // Preço fixo por pessoa

            document.getElementById('resumoNome').textContent = nome;
            document.getElementById('resumoDestino').textContent = destino;
            document.getElementById('resumoQtd').textContent = qtd;
            document.getElementById('resumoTotal').textContent = (qtd * preco).toFixed(2);

            document.getElementById('formReserva').style.display = 'none';
            document.getElementById('pagamentoDiv').style.display = 'block';
        }

        function mostrarFormaPagamento() {
            const forma = document.getElementById('formaPagamento').value;

            document.getElementById('pagamentoPix').style.display = 'none';
            document.getElementById('pagamentoCartao').style.display = 'none';
            document.getElementById('pagamentoBoleto').style.display = 'none';

            if (forma === 'pix') {
                document.getElementById('pagamentoPix').style.display = 'block';
            } else if (forma === 'cartao') {
                document.getElementById('pagamentoCartao').style.display = 'block';
            } else if (forma === 'boleto') {
                document.getElementById('pagamentoBoleto').style.display = 'block';
            }
        }

        function gerarBoleto() {
            const codigoBoleto = '34191.79001 01043.510047 91020.150008 5 85070000010000';
            document.getElementById('linkBoleto').textContent = 'Código do Boleto: ' + codigoBoleto;
        }

        function enviarFormulario() {
            const forma = document.getElementById('formaPagamento').value;
            if (!forma) {
                alert("Escolha uma forma de pagamento.");
                return;
            }

            alert("Pagamento confirmado via " + forma.toUpperCase() + "!");
            document.getElementById('formReserva').submit();
        }
    </script>

    <button class="botao" onclick="location.href='<?= site_url('home') ?>'">⤌</button> 

</body>
</html>
