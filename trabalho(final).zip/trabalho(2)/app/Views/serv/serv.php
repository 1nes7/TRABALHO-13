<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" href="<?= base_url('favicon-novo.ico?v=1') ?>" type="image/x-icon">
    <title>Sustentavelmente</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
       

    

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f8f5;
            color: #2e3d2f;
            line-height: 1.8;
            padding: 40px 20px;
            max-width: 900px;
            margin: auto;
            position: relative;
            z-index: 1;
            background-image: url('/images/floresta.jpg');
  background-size: cover;      
  background-repeat: no-repeat; 
  background-position: center;
        }

        h1 {
            font-size: 2rem;
            color: #2e7d32;
            margin-bottom: 30px;
            border-left: 6px solid #66bb6a;
            padding-left: 15px;
        }

        p {
            margin-bottom: 20px;
            font-size: 1.1rem;
        }

        ul {
            list-style: none;
            margin-bottom: 20px;
        }

        ul li {
            background-color: #ffffff;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            font-size: 1.05rem;
        }

        ul li::before {
            content: "🌱 ";
            margin-right: 8px;
            font-size: 1.2rem;
        }

        strong {
            color: #1b5e20;
        }

        footer {
            margin-top: 40px;
            font-style: italic;
            color: #4b604f;
        }

        @media (max-width: 600px) {
            body {
                padding: 20px 10px;
            }

            h1 {
                font-size: 1.5rem;
            }
        }

        .top-bar {
            position: absolute;
            top: 20px;
            left: 1000px;
            z-index: 1000;
        }

        .login-btn {
            background-color: #2e7d32;
            color: white;
            text-decoration: none;
            padding: 10px 18px;
            border-radius: 6px;
            font-weight: bold;
            transition: background-color 0.3s ease;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .login-btn:hover {
            background-color: #1b5e20;
        }

        .container {
    background-color: rgba(255, 255, 255, 0.85); 
    border-radius: 12px;
    padding: 30px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(2px); 
}
    </style>
</head>
<body>


    <div class="top-bar">
        <a href="<?= site_url('login') ?>" class="login-btn">Login</a>
    </div>

    <div class="container">
    <h1>Bem-vindo ao Sustentavelmente: sua porta de entrada para o turismo consciente e ecológico</h1>

    <p>Você gosta de viajar, mas se preocupa com o impacto que suas escolhas têm no planeta? No Sustentavelmente, acreditamos que é possível explorar o mundo de forma responsável e respeitando a natureza.</p>

    <p>Nosso site foi criado para conectar pessoas com experiências de turismo à práticas sustentáveis. Aqui, você encontrará uma seleção de serviços com base em critérios de responsabilidade ambiental, apoio à comunidade local e preservação dos ecossistemas:</p>

    <ul>
        <li>🏡 <strong>Hospedagens ecológicas:</strong> acomodações que priorizam práticas sustentáveis, como uso de energia renovável, reaproveitamento de água e incentivo ao consumo local.</li>
        <li>🥾 <strong>Trilhas guiadas:</strong> roteiros pela natureza com guias especializados que promovem a educação ambiental e a conservação das áreas visitadas.</li>
        <li>🧭 <strong>Guias locais:</strong> profissionais capacitados que conhecem profundamente a cultura, a fauna e a flora da região — fortalecendo a economia local e proporcionando uma experiência autêntica.</li>
    </ul>

    <p>E porque acreditamos que sustentabilidade também começa no planejamento, oferecemos gratuitamente um serviço de planejamento financeiro para viagens sustentáveis. Com ele, você poderá organizar sua viagem de forma consciente, equilibrando o seu orçamento com escolhas que respeitam o meio ambiente.</p>

    <p><strong>Explore com propósito. Viaje Sustentavelmente.</strong></p>
</div>
</body>
</html>
