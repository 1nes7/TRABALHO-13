<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Sustentavelmente</title>
    <style>
        body { font-family: sans-serif; margin: 0; display: flex; }
        aside { width: 200px; background: #f0f0f0; padding: 20px; }
        aside button {
            display: block;
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            border: none;
            background: #fff;
            border: 1px solid #ccc;
            cursor: pointer;
            text-align: left;
        }
        main { flex: 1; padding: 20px; }
        .titulo { color: #2e7d32; font-size: 24px; margin-bottom: 10px; }
        .sugestoes { margin-top: 20px; }
        .sugestoes img { width: 100px; height: 70px; vertical-align: middle; margin-right: 10px; }
        .sugestao-item { margin-bottom: 20px; }
    </style>
</head>
<body>
    <aside>
        <button onclick="location.href='/'">PÁGINA INICIAL</button>
        <button onclick="location.href='/conta'">CONTA</button>
        <button onclick="location.href='/agendar'">AGENDAR</button>
        <button onclick="location.href='/hospedagem'">HOSPEDAGEM</button>
        <button onclick="location.href='/guias'">GUIA</button>
        <button onclick="location.href='/planejamento'">PLANEJAMENTO FINANCEIRO</button>
    </aside>

    <main>
        <h1 class="titulo">SUSTENTAVELMENTE</h1>
        <h2>ideias de viagem</h2>

        <div class="sugestoes">
            <div class="sugestao-item">
                <img src="/images/parques.jpg" alt="Parques Populares">
                PARQUES POPULARES
            </div>
            <div class="sugestao-item">
                <img src="/images/praia.jpg" alt="Lugares para Família">
                LUGARES PARA FAMÍLIA
            </div>
            <div class="sugestao-item">
                <img src="/images/trem.jpg" alt="Viagem de Trem">
                ARGENTINA: UMA VIAGEM DE TREM SUD EM JUJUY
            </div>
            </div>

        <div style="position: fixed; bottom: 10px; left: 10px; display: flex; align-items: center; background: #f0f0f0; padding: 8px; border-radius: 8px;">
    <img src="/images/tremsolar.jpg" alt="Trem" style="width: 80px; height: auto; border-radius: 5px; margin-right: 10px;">
    <span style="font-size: 14px; color: #333;">Viaje no Trem solar em Jujuy, Argentina</span>
       </div>

    </main>
</body>
</html>
