<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" href="<?= base_url('favicon-novo.ico?v=1') ?>" type="image/x-icon">
    <title>Trilhas Sustentáveis</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 30px;
            background-color: #f4fdf4;
            color: #2e7d32;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .filtros {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 30px;
        }

        select {
            padding: 8px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }

        .trilha {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin: 20px auto;
            max-width: 700px;
            box-shadow: 0 0 10px rgba(0,0,0,0.08);
        }

        .trilha h3 {
            margin: 0 0 10px;
        }

        .trilha p {
            margin: 5px 0;
        }

        .botao {
            width: 90px;
            height: 80px;
            margin-left: 50px;
            color: white;
            background-color:rgb(74, 143, 102);
            font-size: 39px;
        }

        .coisa {
            width: 200px;
            height: 70px;
            margin: 20px auto;
            display: block;
            color: white;
            background-color: rgb(74, 143, 102);
            font-size: 35px;
            text-align: center;
            line-height: 70px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

       
        .modal {
            display: none;
            position: fixed;
            z-index: 10;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }

        .modal-content {
            background-color: white;
            margin: 10% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 400px;
            border-radius: 8px;
        }

        .modal-content input {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .close {
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }

        .submit-btn {
            background-color: #2e7d32;
            color: white;
            padding: 10px;
            width: 100%;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: #1b5e20;
        }
    </style>
</head>
<body>

<h1>Trilhas Sustentáveis</h1>

<form method="get" class="filtros">
    <select name="pais" onchange="this.form.submit()">
        <option value="">-- Selecione o país --</option>
        <?php foreach ($paises as $pais): ?>
            <option value="<?= esc($pais) ?>" <?= ($pais == $paisFiltro) ? 'selected' : '' ?>><?= esc($pais) ?></option>
        <?php endforeach; ?>
    </select>

    <select name="cidade" onchange="this.form.submit()" <?= empty($cidades) ? 'disabled' : '' ?>>
        <option value="">-- Selecione a cidade --</option>
        <?php foreach ($cidades as $cidade): ?>
            <option value="<?= esc($cidade) ?>" <?= ($cidade == $cidadeFiltro) ? 'selected' : '' ?>><?= esc($cidade) ?></option>
        <?php endforeach; ?>
    </select>
</form>

<?php if (empty($trilhas)): ?>
    <p style="text-align:center;">Nenhuma trilha encontrada para os filtros selecionados.</p>
<?php endif; ?>

<?php foreach ($trilhas as $trilha): ?>
    <div class="trilha">
        <h3><?= esc($trilha['nome']) ?></h3>
        <p><strong>País:</strong> <?= esc($trilha['pais']) ?></p>
        <p><strong>Cidade:</strong> <?= esc($trilha['cidade']) ?></p>
        <p><?= esc($trilha['descricao']) ?></p>

        <?php
            $imagem = '';
            if ($trilha['nome'] === 'Trilha da Pedra Furada') $imagem = 'pedrafurada.jpg';
            if ($trilha['nome'] === 'Trilha Inca') $imagem = 'inca.jpg';
            if ($trilha['nome'] === 'Sendero Fitz Roy') $imagem = 'sendero.jpg';
            if ($trilha['nome'] === 'Trilha da Floresta Atlântica') $imagem = 'mataA.jpg';
        ?>

        <?php if ($imagem): ?>
            <div style="text-align: center; margin-top: 15px;">
                <img src="<?= base_url('images/' . $imagem) ?>" alt="<?= esc($trilha['nome']) ?>" style="width: 75%; border-radius: 8px;">
            </div>
        <?php endif; ?>

        <button class="coisa" onclick="abrirFormulario('<?= esc($trilha['nome']) ?>')">Agendar</button>
    </div>
<?php endforeach; ?>

<button class="botao" onclick="location.href='<?= site_url('home') ?>'">⤌</button>


<div id="modalAgendamento" class="modal">
    <div class="modal-content">
        <span class="close" onclick="fecharFormulario()">&times;</span>
        <h2>Agendar Trilha</h2>
        <form action="<?= site_url('trilha/salvarAgendamento') ?>" method="post">
            <label>Lugar:</label>
            <input type="text" name="lugar" id="campoLugar" readonly>
            <label>Nome:</label>
            <input type="text" name="nome" required>
            <label>Data:</label>
            <input type="date" name="data" required>
            <label>Quantidade de pessoas:</label>
            <input type="number" name="quantidade" min="1" required>
            <p><strong>Preço:</strong> R$70 por pessoa</p>

          

             <label for="formaPagamento"><strong>Forma de Pagamento:</strong></label>
        <select id="formaPagamento" onchange="mostrarFormaPagamento()">
            <option value="">Selecione</option>
            <option value="pix">Pix</option>
            <option value="cartao">Cartão de Crédito</option>
            <option value="boleto">Boleto Bancário</option>
        </select>

        <div id="pagamentoPix" style="display: none;">
            <p><strong>Chave Pix:</strong> chavepix@dominio.com</p>
            <p><strong>Escaneie o QR Code:</strong></p>
            <img src="https://api.qrserver.com/v1/create-qr-code/?data=chavepix@dominio.com&size=150x150" alt="QR Code Pix">
        </div>

        <div id="pagamentoCartao" style="display: none;">
            <label for="numeroCartao">Número do Cartão:</label>
            <input type="text" id="numeroCartao" placeholder="1234 5678 9012 3456" maxlength="16">

            <label for="validade">Validade:</label>
            <input type="text" id="validade" placeholder="MM/AA">

            <label for="cvv">CVV:</label>
            <input type="text" id="cvv" maxlength="3" placeholder="123">
        </div>

        <div id="pagamentoBoleto" style="display: none;">
            <p><strong>Boleto gerado:</strong></p>
            <a href="#" onclick="gerarBoleto()">Clique aqui para baixar o boleto</a>
            <p id="linkBoleto" style="color: green;"></p>
        </div>

          <button type="submit" class="submit-btn">Confirmar</button>

        </form>
    </div>
</div>

<script>
    function abrirFormulario(lugar) {
        document.getElementById('campoLugar').value = lugar;
        document.getElementById('modalAgendamento').style.display = 'block';
    }

    function fecharFormulario() {
        document.getElementById('modalAgendamento').style.display = 'none';
    }

    
    window.onclick = function(event) {
        const modal = document.getElementById('modalAgendamento');
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    }

    function mostrarPagamento() {
            const nome = document.getElementById('nome').value;
            const qtd = parseInt(document.getElementById('quantidade').value);
            const destino = document.getElementById('destino').value;

            if (!nome || !qtd || qtd < 1 || !destino) {
                alert('Preencha os campos corretamente.');
                return;
            }

            const preco = 150; // Preço fixo por pessoa

            document.getElementById('resumoNome').textContent = nome;
            document.getElementById('resumoDestino').textContent = destino;
            document.getElementById('resumoQtd').textContent = qtd;
            document.getElementById('resumoTotal').textContent = (qtd * preco).toFixed(2);

            document.getElementById('formReserva').style.display = 'none';
            document.getElementById('pagamentoDiv').style.display = 'block';
        }

        function mostrarFormaPagamento() {
            const forma = document.getElementById('formaPagamento').value;

            document.getElementById('pagamentoPix').style.display = 'none';
            document.getElementById('pagamentoCartao').style.display = 'none';
            document.getElementById('pagamentoBoleto').style.display = 'none';

            if (forma === 'pix') {
                document.getElementById('pagamentoPix').style.display = 'block';
            } else if (forma === 'cartao') {
                document.getElementById('pagamentoCartao').style.display = 'block';
            } else if (forma === 'boleto') {
                document.getElementById('pagamentoBoleto').style.display = 'block';
            }
        }

        function gerarBoleto() {
            const codigoBoleto = '34191.79001 01043.510047 91020.150008 5 85070000010000';
            document.getElementById('linkBoleto').textContent = 'Código do Boleto: ' + codigoBoleto;
        }

        function enviarFormulario() {
            const forma = document.getElementById('formaPagamento').value;
            if (!forma) {
                alert("Escolha uma forma de pagamento.");
                return;
            }

            alert("Pagamento confirmado via " + forma.toUpperCase() + "!");
            document.getElementById('formReserva').submit();
        }
</script>

</body>
</html>
