<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\HospedagemModel;

class HospedagensController extends Controller
{
    public function index()
    {
        $model = new HospedagemModel();

        $paises = $model->getPaises();

       
        $paisFiltro = $this->request->getGet('pais');
        $cidadeFiltro = $this->request->getGet('cidade');

        $hoteis = $model->getHospedagens();

      
        if ($paisFiltro) {
            $hoteis = array_filter($hoteis, function($h) use ($paisFiltro) {
                return strcasecmp($h['pais'], $paisFiltro) === 0;
            });
            $hoteis = array_values($hoteis); 
        }
        if ($cidadeFiltro) {
            $hoteis = array_filter($hoteis, function($h) use ($cidadeFiltro) {
                return strcasecmp($h['cidade'], $cidadeFiltro) === 0;
            });
            $hoteis = array_values($hoteis); 
        }

        $cidades = [];
        if ($paisFiltro) {
            $cidades = $model->getCidadesPorPais($paisFiltro);
        }

        return view('serv/hospedagens', [
            'paises' => $paises,
            'cidades' => $cidades,
            'hoteis' => $hoteis,
            'paisFiltro' => $paisFiltro,
            'cidadeFiltro' => $cidadeFiltro,
        ]);
    }
}
