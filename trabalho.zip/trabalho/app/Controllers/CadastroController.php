<?php

namespace App\Controllers;

use App\Models\CadastroModel;
use CodeIgniter\Controller;

class CadastroController extends Controller
{
    public function index()
    {
        return view('serv/cadastro');
    }

    public function processar()
    {
        $dados = [
            'nome'       => $this->request->getPost('nome'),
            'email'      => $this->request->getPost('email'),
            'telefone'   => $this->request->getPost('telefone'), 
            'cpf'        => $this->request->getPost('cpf'),
            'senha_hash' => password_hash($this->request->getPost('senha_hash'), PASSWORD_DEFAULT),
        ];

        $model = new CadastroModel();

        if ($model->insert($dados)) {
            
            return redirect()->to(site_url('cadastro'))->with('success', 'Cadastro realizado!');
        } else {
            
            return redirect()->back()->withInput()->with('error', 'Erro ao cadastrar.');
        }
    }
}
