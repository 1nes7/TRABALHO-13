<?php

namespace App\Controllers;
use App\Models\UsuarioModel;

class Usuario extends BaseController
{
    public function perfil()
    {
      $usuario = session('usuario');

if (!$usuario || !isset($usuario['id'])) {
    return 'Usuário não logado ou sessão perdida.';
}

$usuarioModel = new UsuarioModel();
$usuarioId = $usuario['id'];
$usuario = $usuarioModel->find($usuarioId);

return view('usuario/perfil', ['usuario' => $usuario]);
    }
}

