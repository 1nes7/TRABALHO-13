<?php

namespace App\Controllers;
use App\Models\UsuarioModel;

class Usuario extends BaseController
{
    public function perfil()
    {
        $sessionUsuario = session('usuario');

        if (!$sessionUsuario || !isset($sessionUsuario['id'])) {
            return redirect()->to('/login')->with('error', 'Usuário não logado.');
        }

        $usuarioModel = new UsuarioModel();
        $usuarioId = $sessionUsuario['id'];

        $usuario = $usuarioModel->find($usuarioId);

        return view('usuario/perfil', ['usuario' => $usuario]);
    }

    public function uploadFoto()
    {
        $sessionUsuario = session('usuario');

        if (!$sessionUsuario || !isset($sessionUsuario['id'])) {
            return redirect()->to('/login')->with('error', 'Sessão expirada.');
        }

        $file = $this->request->getFile('foto');

        if ($file && $file->isValid() && !$file->hasMoved()) {
            $newName = $file->getRandomName();
            $file->move(ROOTPATH . 'public/uploads', $newName); // Salva em public/uploads

            // Atualiza o banco de dados
            $usuarioModel = new UsuarioModel();
            $usuarioModel->update($sessionUsuario['id'], ['foto' => $newName]);

            // Atualiza os dados na sessão
            $sessionUsuario['foto'] = $newName;
            session()->set('usuario', $sessionUsuario);

            return redirect()->to('/usuario/perfil')->with('success', 'Foto de perfil atualizada.');
        }

        return redirect()->back()->with('error', 'Erro ao enviar a foto.');
    }

public function atualizarPerfil()
{
    $sessionUsuario = session('usuario');
    if (!$sessionUsuario || !isset($sessionUsuario['id'])) {
        return redirect()->to('/login')->with('error', 'Sessão expirada.');
    }

    $usuarioModel = new \App\Models\UsuarioModel();

    // Pega os dados do POST
    $data = [
        'nome' => $this->request->getPost('nome'),
        'email' => $this->request->getPost('email'),
        'telefone' => $this->request->getPost('telefone'),
        'cpf' => $this->request->getPost('cpf'),
    ];

    // Validação simples, você pode usar validação mais robusta se quiser
    if (empty($data['nome']) || empty($data['email'])) {
        return redirect()->back()->with('error', 'Nome e email são obrigatórios.')->withInput();
    }

    // Tratamento da foto (opcional)
    $file = $this->request->getFile('foto');
    if ($file && $file->isValid() && !$file->hasMoved()) {
        $newName = $file->getRandomName();
        $file->move(ROOTPATH . 'public/uploads', $newName);
        $data['foto'] = $newName;
    }

    // Atualiza o banco de dados
    $usuarioModel->update($sessionUsuario['id'], $data);

    // Atualiza a sessão
    $usuarioAtualizado = $usuarioModel->find($sessionUsuario['id']);
    session()->set('usuario', $usuarioAtualizado);

    return redirect()->to('/usuario/perfil')->with('success', 'Perfil atualizado com sucesso.');
}
}

