<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\GuiaContratadoModel;

class GuiasController extends Controller
{
    public function index()
    {
        return view('serv/guias');
    }

    public function contratar()
    {
        $request = \Config\Services::request();

       
        $dados = [
            'nome' => $request->getPost('nome'),
            'quantidade' => $request->getPost('quantidade'),
            'destino' => $request->getPost('destino'),
            'guia_particular' => $request->getPost('guia_particular') === 'Sim' ? 1 : 0,
            'trilha' => $request->getPost('trilha') === 'Sim' ? 1 : 0,
        ];

        // Salva no banco
        $model = new GuiaContratadoModel();
        $model->insert($dados);

        // Seleciona guia aleatoriamente
        $guias = [
            ['nome' => 'Carlos Silva', 'imagem' => 'guia1.jpg'],
            ['nome' => 'Maria Oliveira', 'imagem' => 'guia2.jpg'],
            ['nome' => 'João Souza', 'imagem' => 'guia3.jpg'],
            ['nome' => 'Ana Lima', 'imagem' => 'guia4.jpg'],
        ];

        $guiaSelecionado = $guias[array_rand($guias)];

        return view('serv/guia_confirmado', [
            'dados' => $dados,
            'guia' => $guiaSelecionado
        ]);
    }
}
