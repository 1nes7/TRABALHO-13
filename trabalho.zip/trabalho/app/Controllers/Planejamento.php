<?php

namespace App\Controllers;

use App\Models\PlanejamentoModel;

class Planejamento extends BaseController
{
    public function index()
    {
        return view('serv/planejamento');
    }

    public function calcular()
    {
        $quantidade_pessoas = $this->request->getPost('quantidade_pessoas');
        $hospedagem = $this->request->getPost('hospedagem') ? 150 : 0;
        $trilhas = $this->request->getPost('trilhas') ? 70 : 0;
        $lojas_locais = $this->request->getPost('lojas_locais') ? 200 : 0;
        $guia_particular = $this->request->getPost('guia_particular') ? 200 : 0;

        $total = ($hospedagem + $trilhas + $lojas_locais + $guia_particular) * $quantidade_pessoas;

        return view('serv/planejamento', ['total' => $total]);
    }
}
