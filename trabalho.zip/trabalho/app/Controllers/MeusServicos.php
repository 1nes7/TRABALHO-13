<?php

namespace App\Controllers;

use App\Models\ServicoModel;

class MeusServicos extends BaseController
{
    public function index()
    {
        $model = new ServicoModel();
        $dados['servicos'] = $model->getServicosAgendados();

        return view('serv/servico', $dados);
    }
}
