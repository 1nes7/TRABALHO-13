<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\TrilhaModel;
use App\Models\AgendamentoModel;

class TrilhasController extends Controller
{
    public function salvarAgendamento() {
    $request = \Config\Services::request();

    $lugar = $request->getPost('lugar');
    $nome = $request->getPost('nome');
    $data = $request->getPost('data');
    $quantidade = $request->getPost('quantidade');

    
    $agendamentoModel = new AgendamentoModel();
    $agendamentoModel->insert([
        'lugar' => $lugar,
        'nome' => $nome,
        'data' => $data,
        'quantidade' => $quantidade
    ]);

    
    $guias = [
        ['nome' => 'Carlos Silva', 'imagem' => 'guia1.jpg'],
        ['nome' => 'Maria Oliveira', 'imagem' => 'guia2.jpg'],
        ['nome' => 'João Souza', 'imagem' => 'guia3.jpg'],
        ['nome' => 'Ana Lima', 'imagem' => 'guia4.jpg'],
    ];

    $guiaSelecionado = $guias[array_rand($guias)];

    return view('serv/confirmacao', [
        'lugar' => $lugar,
        'nome' => $nome,
        'data' => $data,
        'quantidade' => $quantidade,
        'guia' => $guiaSelecionado
    ]);
}

    public function index()
    {
        $model = new TrilhaModel();

        $paises = $model->getPaises();

        $paisFiltro = $this->request->getGet('pais');
        $cidadeFiltro = $this->request->getGet('cidade');

        $trilhas = $model->getTrilhas();

        if ($paisFiltro) {
            $trilhas = array_filter($trilhas, fn($t) => $t['pais'] === $paisFiltro);
            $trilhas = array_values($trilhas);
        }

        if ($cidadeFiltro) {
            $trilhas = array_filter($trilhas, fn($t) => $t['cidade'] === $cidadeFiltro);
            $trilhas = array_values($trilhas);
        }

        $cidades = [];
        if ($paisFiltro) {
            $cidades = $model->getCidadesPorPais($paisFiltro);
        }

        return view('serv/trilhas', [
            'paises' => $paises,
            'cidades' => $cidades,
            'trilhas' => $trilhas,
            'paisFiltro' => $paisFiltro,
            'cidadeFiltro' => $cidadeFiltro,
        ]);
    }



    
}
