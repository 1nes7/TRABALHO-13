<?php

namespace App\Controllers;


class PaginainicialController extends BaseController
{
    public function index()
    {
        return view('serv/paginainicial');
    }
}