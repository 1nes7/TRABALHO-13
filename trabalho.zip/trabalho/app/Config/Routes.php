<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */


$routes->get('/', 'Serv::index');  

// Cadastro
$routes->get('/cadastro', 'CadastroController::index');
$routes->post('/cadastro/processar', 'CadastroController::processar');



// Planejamento
$routes->get('planejamento', 'Planejamento::index');
$routes->post('planejamento/calcular', 'Planejamento::calcular');

// Login
$routes->get('login', 'LoginController::index');
$routes->post('login/processar', 'LoginController::processar');
$routes->get('logout', 'LoginController::logout');

// Página protegida 
$routes->get('home', 'HomeController::index', ['filter' => 'auth']);

$routes->get('hospedagem', 'HospedagensController::index');
$routes->get('guias', 'GuiasController::index');
$routes->post('guias/contratar', 'GuiasController::contratar');
$routes->get('trilhas', 'TrilhasController::index');
$routes->post('trilha/salvarAgendamento', 'TrilhasController::salvarAgendamento');

$routes->get('meus-servicos', 'MeusServicos::index');
$routes->get('hospedagemform', 'Reservas::index');
$routes->get('reservas/salvar', 'Reservas::salvar');
$routes->get('perfil', 'Usuario::perfil');


$routes->get('usuario/perfil', 'Usuario::perfil');
$routes->post('usuario/atualizarPerfil', 'Usuario::atualizarPerfil');


$routes->setAutoRoute(true);
