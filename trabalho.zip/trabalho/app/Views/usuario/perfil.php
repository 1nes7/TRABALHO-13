<!DOCTYPE html>
<html>
<head>
    <title>Perfil do Usuário</title>
</head>
<body>
   <?php $usuario = session()->get('usuario'); ?>
<?php if ($usuario): ?>
    <p>Bem-vindo, <?= esc($usuario['nome']) ?>!</p>
<?php endif; ?>
<?php if ($usuario): ?>
    <h1>Perfil</h1>
    <p><strong>Nome:</strong> <?= esc($usuario['nome']) ?></p>
    <p><strong>Email:</strong> <?= esc($usuario['email']) ?></p>
<?php else: ?>
    <p>Usuário não encontrado.</p>
<?php endif; ?>


    <h1>Perfil</h1>
    <p><strong>Nome:</strong> <?= esc($usuario['nome']) ?></p>
    <p><strong>Email:</strong> <?= esc($usuario['email']) ?></p>

    <?php if (!empty($usuario['foto'])): ?>
        <img src="<?= base_url('uploads/'.$usuario['foto']) ?>" alt="Foto de Perfil" width="150">
    <?php endif; ?>
</body>
</html>
