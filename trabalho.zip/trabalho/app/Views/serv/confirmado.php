<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Reserva Confirmada</title>
    <style>
        body {
            background-color: #e8f5e9;
            font-family: 'Roboto', sans-serif;
            color: #2e7d32;
            padding: 40px;
            text-align: center;
        }

        .confirmation-box {
            background: #ffffff;
            padding: 30px;
            border-radius: 10px;
            display: inline-block;
            box-shadow: 0 6px 18px rgba(0,0,0,0.1);
        }

        h1 {
            font-size: 32px;
            margin-bottom: 20px;
        }

        p {
            font-size: 18px;
            margin: 10px 0;
        }

        .btn-voltar {
            margin-top: 25px;
            display: inline-block;
            padding: 12px 20px;
            background-color: #2e7d32;
            color: #ffffff;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .btn-voltar:hover {
            background-color: #1b5e20;
        }
    </style>
</head>
<body>

    <div class="confirmation-box">
        <h1>✅ Reserva Confirmada!</h1>
        <p><strong>Hotel:</strong> <?= esc($reserva['hotel']) ?></p>
        <p><strong>Nome:</strong> <?= esc($reserva['nome']) ?></p>
        <p><strong>Quantidade de Pessoas:</strong> <?= esc($reserva['quantidade']) ?></p>
        <p><strong>Preço por Pessoa:</strong> R$ <?= number_format($reserva['preco'], 2, ',', '.') ?></p>
        <p><strong>Total:</strong> R$ <?= number_format($reserva['preco'] * $reserva['quantidade'], 2, ',', '.') ?></p>

        <a class="btn-voltar" href="<?= site_url('/') ?>">Voltar para a Página Inicial</a>
    </div>

</body>
</html>
