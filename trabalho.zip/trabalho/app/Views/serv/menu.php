<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sustentavelmente</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding-top: 70px; /* espaço para a navbar */
            background-color: #f4f4f4;
        }

        .navbar {
            background-color: #333;
        }

        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 24px;
        }

        .navbar-brand:hover {
            color: #a8e6cf;
        }

        .nav-link {
            color: white !important;
        }

        .nav-link:hover {
            background-color: rgb(74, 143, 102);
            border-radius: 5px;
        }

        .accordion-button::before {
            content: '➤'; 
            font-size: 18px;
            margin-right: 10px; 
            transition: transform 0.2s ease-in-out;
        }

        .accordion-button.collapsed::before {
            content: '›'; 
            transform: rotate(90deg); 
        }

        .accordion-button:not(.collapsed)::before {
            content: '⌄'; 
            transform: rotate(0deg); 
        }

        .accordion-button {
            background-color: #444 !important;
            color: white !important;
        }

        .accordion-button:not(.collapsed) {
            background-color: #666 !important;
        }

        .accordion-body {
            background-color: #555;
        }

        .menu-subitem {
            color: white;
            padding: 8px 12px;
            cursor: pointer;
        }

        .menu-subitem:hover {
            background-color: rgb(74, 143, 102);
            border-radius: 5px;
        }

        .content {
            padding: 20px;
        }
    </style>
</head>
<body>

    <!-- Menu superior -->
    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?= site_url('/') ?>">Sustentavelmente</a>
            <button class="navbar-toggler bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarMenu">
                <ul class="navbar-nav ms-auto">

                    <li class="nav-item">
                        <a class="nav-link" href="<?= site_url('perfil') ?>">Conta</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?= site_url('meus-servicos') ?>">Meus Serviços</a>
                    </li>

                    <!-- Menu suspenso com accordion -->
                    <li class="nav-item dropdown">
                        <div class="accordion" id="accordionAgendar" style="background: transparent;">
                            <div class="accordion-item bg-transparent border-0">
                                <h2 class="accordion-header" id="headingAgendar">
                                    <button class="accordion-button collapsed bg-transparent text-white" type="button" data-bs-toggle="collapse" data-bs-target="#collapseAgendar">
                                        Agendar
                                    </button>
                                </h2>
                                <div id="collapseAgendar" class="accordion-collapse collapse" aria-labelledby="headingAgendar" data-bs-parent="#accordionAgendar">
                                    <div class="accordion-body p-2">
                                        <div class="menu-subitem" onclick="location.href='<?= site_url('hospedagem') ?>'">Hospedagem</div>
                                        <div class="menu-subitem" onclick="location.href='<?= site_url('trilhas') ?>'">Trilhas</div>
                                        <div class="menu-subitem" onclick="location.href='<?= site_url('guias') ?>'">Guias</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?= site_url('planejamento') ?>">Planejamento Financeiro</a>
                    </li>

                </ul>
            </div>
        </div>
    </nav>

    <!-- Conteúdo da página -->
   

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
