<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SustentavelMente</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style>
      
      body {
    background-color:rgb(190, 255, 216);

      }
        /* Conteúdo principal */
        .content {
            background-color:rgb(209, 245, 239);
            flex: 1;
            padding: 40px;
            display: flex;
            flex-direction: column;
            align-items: flex-start; 
        }

        /* Título principal */
        .title {
            font-family: "Fontdiner Swanky", serif;
            font-size: 48px;
            font-weight: 700;
            color: #2c6e49;
            margin-bottom: 20px;
            text-align: center; /
            width: 100%; 
        }

       
        .section-title {
            font-style: italic;
            font-size: 24px;
            color: rgb(0, 0, 0);
            margin-top: 20px;
            margin-bottom: 10px;
             text-align: center;
        }

       
        .travel-idea {
            display: flex;
            align-items: center;
            margin-top: 20px;
            align-self: flex-start; 
        }

        .travel-idea img {
            width: 200px; 
            height: 160px;
            object-fit: cover;
            margin-right: 15px;
            border-radius: 5px;
        }

        .travel-idea div {
            font-size: 20px;
            color: rgb(88, 87, 87);
        }

        /* Linha horizontal */
        .horizontal-line {
            width: 70%; 
            height: 2px; 
            background-color:rgb(197, 195, 195);
            margin-top: 20px;
            align-self: flex-start; 
        }

        


        /* Barra de pesquisa */
        .search-bar {
            position: absolute; 
            top: 20px;
            right: 20px; 
        }

        .search-bar input {
            padding: 5px;
            font-size: 14px;
            border-radius: 5px;
            border: 1px solid #ccc;
            width: 200px; 
        }

        

    </style>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fontdiner+Swanky&display=swap" rel="stylesheet">
</head>
<body>
    <?= view('serv/menu') ?>

    <div class="content">
        <div class="title"></div>

     




        <div class="section-title">Ideias de Viagem</div>

       <div class="travel-idea">
    <img src="<?= base_url('images/tremsolar.jpg') ?>" alt="Trem Solar">
    <div>
        <a href="https://www.argentina.travel/pt/novidades/trem-solar-da-quebrada-como-e-o-passeio-pelas-magicas-vilas-de-jujuy" target="_blank" style="color: inherit; text-decoration: none;">
            Viajem no trem solar em Jujuy, Argentina
        </a>
    </div>
</div>
        <!-- Linha horizontal abaixo da imagem -->
        <div class="horizontal-line"></div>

        <div class="travel-idea">
            <img src="<?= base_url('images/chile.jpg') ?>" alt="Chile">
            <div>  <a href="https://www.kayak.com.br/news/road-trips-pelo-brasil/" target="_blank" style="color: inherit; text-decoration: none;"> 
                Interessados em road trip</div>
    </a>
        </div>
        


        <div class="horizontal-line"></div>
        
        <div class="travel-idea">
            <img src="<?= base_url('images/rio.jpg') ?>" alt="Rio">
            <div> 
               <a href="https://blog.blablacar.com.br/destinos/turismo-sustentavel-no-brasil" target="_blank" style="color: inherit; text-decoration: none;"> 
                 Conecte-se com a natureza do Brasil!
                </a>
               </div>
        </div>
    

    <div class="horizontal-line"></div>
        
        <div class="travel-idea">
            <img src="<?= base_url('images/comidaveafeia.jpg') ?>" alt="Comida">
            <div> 
               <a href="https://viajarverde.com.br/ecogastronomia-para-um-turismo-gastronomico-sustentavel/" target="_blank" style="color: inherit; text-decoration: none;"> 
                 A importância da Ecogastronomia
                </a>
               </div>
        </div>
        
        <div class="horizontal-line"></div>
        
        <div class="travel-idea">
            <img src="<?= base_url('images/afroturismo.jpg') ?>" alt="afro">
            <div> 
               <a href="https://www.terra.com.br/noticias/brasil/cidades/conheca-10-roteiros-para-praticar-o-afroturismo-no-litoral-interior-ou-capital-de-sp,4508cb964b122744a4a16eecd6327616wkvxu0n3.html" target="_blank" style="color: inherit; text-decoration: none;"> 
                Afroturismo Nacional
                </a>
               </div>
        </div>

         <div class="horizontal-line"></div>
        
        <div class="travel-idea">
            <img src="<?= base_url('images/aguastermais.jpg') ?>" alt="agua">
            <div> 
               <a href="https://viagemeturismo.abril.com.br/brasil/8-destinos-com-aguas-termais-para-curtir-ao-redor-do-brasil/" target="_blank" style="color: inherit; text-decoration: none;"> 
                Águas termais do Brasil
                </a>
               </div>
        </div>

          <div class="horizontal-line"></div>
        
        <div class="travel-idea">
            <img src="<?= base_url('images/parque.jpeg') ?>" alt="parque">
            <div> 
               <a href="https://www.buser.com.br/destinos/pontos-turisticos/parques/parques-ecologicos/ce" target="_blank" style="color: inherit; text-decoration: none;"> 
                 Parques ecológicos no Ceará 
                </a>
               </div>
        </div>
        
    



</body>
</html>
