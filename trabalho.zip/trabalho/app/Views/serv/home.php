<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>SustentavelMente</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Roboto:wght@400;500&display=swap" rel="stylesheet" />
    <style>
        /* Reset básico */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Roboto', sans-serif;
            background: #f0faf4;
            color: #2e5339;
            line-height: 1.6;
            min-height: 100vh;
            padding-bottom: 40px;
        }

        /* Cabeçalho fixo */
        header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: #3a7a40;
            color: white;
            padding: 20px 0;
            text-align: center;
            font-family: 'Playfair Display', serif;
            font-size: 2.8rem;
            box-shadow: 0 2px 6px rgba(0,0,0,0.15);
            z-index: 100;
        }

        /* Container principal */
        .container {
            max-width: 900px;
            margin: 100px auto 40px;
            padding: 0 20px;
        }

        /* Título seção */
        .section-title {
            font-family: 'Playfair Display', serif;
            font-style: italic;
            font-size: 2.2rem;
            color: #2e5339;
            margin-bottom: 30px;
            text-align: center;
            border-bottom: 3px solid #a1c997;
            padding-bottom: 10px;
        }

        /* Lista de ideias em grid responsivo */
        .ideas-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
        }

        /* Card de ideia */
        .travel-idea {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(46, 83, 57, 0.1);
            overflow: hidden;
            transition: transform 0.25s ease, box-shadow 0.25s ease;
            display: flex;
            flex-direction: column;
        }

        .travel-idea:hover {
            transform: translateY(-6px);
            box-shadow: 0 8px 20px rgba(46, 83, 57, 0.25);
        }

        .travel-idea img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            border-bottom: 4px solid #4caf50;
        }

        .travel-idea-content {
            padding: 15px 20px;
            flex-grow: 1;
            display: flex;
            align-items: center;
        }

        .travel-idea-content a {
            color: #2e5339;
            font-weight: 500;
            font-size: 1.1rem;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .travel-idea-content a:hover {
            color: #4caf50;
            text-decoration: underline;
        }

        /* Linha separadora (opcional) */
        .horizontal-line {
            height: 1px;
            background-color: #c7c7c7;
            margin: 40px 0;
            border-radius: 2px;
        }

        /* Busca (se quiser ativar depois) */
        .search-bar {
            position: fixed;
            top: 30px;
            right: 30px;
            z-index: 110;
        }

        .search-bar input {
            padding: 8px 12px;
            font-size: 1rem;
            border-radius: 20px;
            border: 1.5px solid #4caf50;
            width: 240px;
            outline-color: #4caf50;
            transition: box-shadow 0.3s ease;
        }

        .search-bar input:focus {
            box-shadow: 0 0 10px #4caf50aa;
            border-color: #4caf50;
        }

        /* Responsividade */
        @media (max-width: 600px) {
            header {
                font-size: 2rem;
                padding: 15px 0;
            }

            .section-title {
                font-size: 1.7rem;
            }

            .travel-idea img {
                height: 140px;
            }
        }

    </style>
</head>
<body>

<?= view('serv/menu') ?>
   

    <!-- <div class="search-bar">
        <input type="text" placeholder="Pesquisar..." />
    </div> -->

    <div class="container">
        <h2 class="section-title">Ideias de Viagem</h2>

        <div class="ideas-grid">

            <div class="travel-idea">
                <img src="<?= base_url('images/tremsolar.jpg') ?>" alt="Trem Solar" />
                <div class="travel-idea-content">
                    <a href="https://www.argentina.travel/pt/novidades/trem-solar-da-quebrada-como-e-o-passeio-pelas-magicas-vilas-de-jujuy" target="_blank" rel="noopener noreferrer">
                        Viaje no trem solar em Jujuy, Argentina
                    </a>
                </div>
            </div>

            <div class="travel-idea">
                <img src="<?= base_url('images/chile.jpg') ?>" alt="Chile" />
                <div class="travel-idea-content">
                    <a href="https://www.kayak.com.br/news/road-trips-pelo-brasil/" target="_blank" rel="noopener noreferrer">
                        Interessados em road trip
                    </a>
                </div>
            </div>

            <div class="travel-idea">
                <img src="<?= base_url('images/rio.jpg') ?>" alt="Rio" />
                <div class="travel-idea-content">
                    <a href="https://blog.blablacar.com.br/destinos/turismo-sustentavel-no-brasil" target="_blank" rel="noopener noreferrer">
                        Conecte-se com a natureza do Brasil!
                    </a>
                </div>
            </div>

            <div class="travel-idea">
                <img src="<?= base_url('images/comidaveafeia.jpg') ?>" alt="Comida" />
                <div class="travel-idea-content">
                    <a href="https://viajarverde.com.br/ecogastronomia-para-um-turismo-gastronomico-sustentavel/" target="_blank" rel="noopener noreferrer">
                        A importância da Ecogastronomia
                    </a>
                </div>
            </div>

            <div class="travel-idea">
                <img src="<?= base_url('images/afroturismo.jpg') ?>" alt="Afroturismo" />
                <div class="travel-idea-content">
                    <a href="https://www.terra.com.br/noticias/brasil/cidades/conheca-10-roteiros-para-praticar-o-afroturismo-no-litoral-interior-ou-capital-de-sp,4508cb964b122744a4a16eecd6327616wkvxu0n3.html" target="_blank" rel="noopener noreferrer">
                        Afroturismo Nacional
                    </a>
                </div>
            </div>

            <div class="travel-idea">
                <img src="<?= base_url('images/aguastermais.jpg') ?>" alt="Águas Termais" />
                <div class="travel-idea-content">
                    <a href="https://viagemeturismo.abril.com.br/brasil/8-destinos-com-aguas-termais-para-curtir-ao-redor-do-brasil/" target="_blank" rel="noopener noreferrer">
                        Águas termais do Brasil
                    </a>
                </div>
            </div>

            <div class="travel-idea">
                <img src="<?= base_url('images/parque.jpeg') ?>" alt="Parques Ecológicos" />
                <div class="travel-idea-content">
                    <a href="https://www.buser.com.br/destinos/pontos-turisticos/parques/parques-ecologicos/ce" target="_blank" rel="noopener noreferrer">
                        Parques ecológicos no Ceará
                    </a>
                </div>
            </div>

        </div>
    </div>
</body>
</html>
