<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css">
    <style>
        
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

     
        .container {
            max-width: 500px;
            margin: 50px auto;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

      
        h2 {
            text-align: center;
            color: #2c6e49;
            margin-bottom: 20px;
        }

       
        .form-label {
            font-weight: bold;
            color: #2c6e49;
        }

        
        .form-control {
            border-radius: 5px;
            border: 1px solid #2c6e49;
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.12);
            margin-bottom: 15px;
        }

        
        .btn-primary {
            background-color:rgb(74, 143, 102);
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            width: 100%;
            font-size: 16px;
            cursor: pointer;
        }

        .btn-primary:hover {
            background-color: #245c3a;
        }

      
        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #888;
        }

        .botao {
            width: 90px;
            height: 80px;
            margin-left: 50px;
            color: white;
            background-color:rgb(74, 143, 102);
            font-size: 39px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Cadastro</h2>
        <form method="POST" action="<?php echo site_url('cadastro/processar'); ?>">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome Completo</label>
                <input type="text" class="form-control" id="nome" name="nome" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">E-mail</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="cpf" class="form-label">CPF</label>
                <input type="text" class="form-control" id="cpf" name="cpf" required>
            </div>
            <div class="mb-3">
                <label for="senha" class="form-label">Senha</label>
                <input type="password" class="form-control" id="senha" name="senha_hash" required>
            </div>
            <button type="submit" class="btn btn-primary">Cadastrar</button>
        </form>
       <div class="footer">
    <p>&copy; Turismo Sustentável. Todos os direitos reservados.</p>
    <p>
        Já possui cadastro?
        <button type="button" class="btn btn-link p-0 align-baseline" 
            onclick="location.href='<?= site_url('login') ?>'">
            Login
        </button>
    </p>
</div>

    </div>

      <button class="botao" onclick="location.href='<?= site_url('/') ?>'">⤌</button> 

      

</body>
</html>

