<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meus Serviços</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

 <style>

/* Reset básico */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Corpo da página */
body {
    background-image: url('Imagens/servico.jpg');
    background-size: cover; /* Ajusta a imagem para cobrir toda a área */
    background-position: center center; /* Centraliza a imagem */
    background-attachment: fixed; /* Faz a imagem de fundo ficar fixa durante o rolar da página */
    height: 100vh; /* Garante que a altura da página ocupe toda a altura da janela */
    display: flex;
    justify-content: center;
    align-items: center;
}


/* Container principal */
.container {
    width: 100%;
    max-width: 1200px;
    padding: 200px;
    background-color: rgba(255, 255, 255, 0.8); /* Fundo semitransparente */
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

/* Título */
h1 {
    text-align: center;
    color: #2c3e50;
    margin-bottom: 20px;
}

/* Accordion */
.accordion-button {
    background-color: #27ae60;
    color: white;
    font-weight: bold;
    border-radius: 10px;
}

.accordion-button:not(.collapsed) {
    background-color: #2ecc71;
}

.accordion-body {
    background-color: #ecf0f1;
    border-radius: 5px;
}

/* Responsividade */
@media (max-width: 768px) {
    body {
        padding: 10px;
    }

    .container {
        padding: 15px;
    }

    h1 {
        font-size: 1.5rem;
    }
}





      </style>

</head>
<body>



  <div class="container">
        <div class="content">
            <h1>Meus Serviços</h1>
            
<div class="accordion" id="accordionServicos">
    <?php
    $servicos = ['Hospedagem', 'Trilhas', 'Guias'];
    foreach ($servicos as $index => $servico) :
        $collapseId = 'collapse' . $index;
        $headingId = 'heading' . $index;
    ?>
        <div class="accordion-item">
            <h2 class="accordion-header" id="<?= $headingId ?>">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#<?= $collapseId ?>" aria-expanded="true" aria-controls="<?= $collapseId ?>">
                    <?= $servico ?>
                </button>
            </h2>
            <div id="<?= $collapseId ?>" class="accordion-collapse collapse <?= $index === 0 ? 'show' : '' ?>" aria-labelledby="<?= $headingId ?>" data-bs-parent="#accordionServicos">
                <div class="accordion-body">
                    <!-- Conteúdo do serviço -->
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>


            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    
</body>
</html>
