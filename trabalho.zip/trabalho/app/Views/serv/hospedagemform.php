<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reserva com Pagamento</title>

    <style>
        /* Estilo compartilhado */
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }

        form, .pagamento {
            max-width: 500px;
            margin: 40px auto;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
            color: #2e7d32;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            font-size: 16px;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #cccccc;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 15px;
        }

        input:focus {
            outline: none;
            border-color: #4caf50;
            box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.2);
        }

        button {
            width: 100%;
            padding: 14px;
            background-color: #2e7d32;
            color: #ffffff;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        button:hover {
            background-color: #1b5e20;
        }

        .pagamento {
            display: none;
            text-align: center;
        }

        .pagamento h3 {
            margin-bottom: 20px;
        }

        .botao {
            width: 90px;
            height: 80px;
            margin-left: 50px;
            color: white;
            background-color:rgb(74, 143, 102);
            font-size: 39px;
        }
    </style>
</head>
<body>

    <!-- Formulário de reserva -->
    <form id="formReserva">
        <label for="hotel"><strong>Nome do Hotel:</strong></label>
        <input type="text" id="hotel" name="hotel" value="EcoHotel Verde Vida" readonly>

        <label for="nome"><strong>Seu Nome:</strong></label>
        <input type="text" id="nome" name="nome" required>

        <label for="quantidade"><strong>Quantidade de Pessoas:</strong></label>
        <input type="number" id="quantidade" name="quantidade" min="1" required>

        <label for="preco"><strong>Preço por Pessoa:</strong></label>
<input type="text" id="preco" name="preco" value="150" readonly>

        <button type="button" onclick="mostrarPagamento()">Reservar</button>
    </form>

    <!-- Tela de pagamento fantasma -->
    <div class="pagamento" id="pagamentoDiv">
        <h3>Confirmação de Pagamento</h3>
        <p><strong>Nome:</strong> <span id="resumoNome"></span></p>
        <p><strong>Hotel:</strong> EcoHotel Verde Vida</p>
        <p><strong>Quantidade:</strong> <span id="resumoQtd"></span></p>
        <p><strong>Total:</strong> R$ <span id="resumoTotal"></span></p>

        <button onclick="enviarFormulario()">Confirmar Pagamento</button>
    </div>

    <script>
        function mostrarPagamento() {
            const nome = document.getElementById('nome').value;
            const qtd = parseInt(document.getElementById('quantidade').value);
            const preco = parseFloat(document.getElementById('preco').value);

            if (!nome || !qtd || qtd < 1) {
                alert('Preencha os campos corretamente.');
                return;
            }

            // Preencher dados no resumo
            document.getElementById('resumoNome').textContent = nome;
            document.getElementById('resumoQtd').textContent = qtd;
            document.getElementById('resumoTotal').textContent = (qtd * preco).toFixed(2);

            // Esconde o form e mostra a tela de pagamento
            document.getElementById('formReserva').style.display = 'none';
            document.getElementById('pagamentoDiv').style.display = 'block';
        }

        function enviarFormulario() {
            // Envia o formulário após confirmação
            document.getElementById('formReserva').submit();
        }
    </script>

<button class="botao" onclick="location.href='<?= site_url('home') ?>'">⤌</button> 

</body>
</html>
