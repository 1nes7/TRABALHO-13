<h2>Opções de Hospedagem</h2>
<ul>
<?php foreach ($hospedagens as $hospedagem): ?>
    <li>
        <strong><?= esc($hospedagem['nome']) ?></strong><br>
        Localização: <?= esc($hospedagem['localizacao']) ?><br>
        Preço: R$ <?= esc($hospedagem['preco']) ?><br>
        <?= esc($hospedagem['descricao']) ?>
    </li>
<?php endforeach; ?>
</ul>
