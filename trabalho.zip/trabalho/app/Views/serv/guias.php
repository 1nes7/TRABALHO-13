<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Guias Turísticos - Sustentavelmente</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f1f7f1;
            padding: 30px;
            color: #2e7d32;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

        form {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        label {
            font-weight: bold;
            display: block;
            margin-top: 15px;
        }

        input[type="text"],
        input[type="number"],
        select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }

        .checkbox-group {
            margin-top: 10px;
        }

        .checkbox-group label {
            font-weight: normal;
            display: flex;
            align-items: center;
        }

        .checkbox-group input {
            margin-right: 10px;
        }

        button {
            margin-top: 25px;
            padding: 12px 20px;
            background-color: #2e7d32;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            width: 100%;
        }

        button:hover {
            background-color: #1b5e20;
        }

         .botao {
            width: 90px;
            height: 80px;
            margin-left: 50px;
            color: white;
            background-color:rgb(74, 143, 102);
            font-size: 39px;
        }
    </style>
</head>
<body>

    <h1>Contratar Guia Turístico</h1>

    <form action="<?= site_url('guias/contratar') ?>" method="post">
        <label for="nome">Seu nome:</label>
        <input type="text" name="nome" id="nome" required>

        <label for="quantidade">Quantidade de pessoas:</label>
        <input type="number" name="quantidade" id="quantidade" min="1" required>

        <label for="destino">Destino:</label>
<select name="destino" id="destino" required>
    <option value="">Selecione um destino</option>
    <option value="Chapada dos Veadeiros">Chapada dos Veadeiros</option>
    <option value="Serra da Canastra">Serra da Canastra</option>
    <option value="Fernando de Noronha">Fernando de Noronha</option>
    <option value="Trilha Verde Encantada">Trilha Verde Encantada</option>
    <option value="Vale das Águas Claras">Vale das Águas Claras</option>
    <option value="Montanhas da Liberdade">Montanhas da Liberdade</option>
</select>


        <div class="checkbox-group">
            <label>
                <input type="checkbox" name="guia_particular" value="Sim">
                Guia particular (vai lhe guiar mesmo depois das trilhas)
            </label>
        </div>

        <div class="checkbox-group">
            <label>
                <input type="checkbox" name="trilha" value="Sim">
                Inclui trilha guiada
            </label>
        </div>

        <button type="submit">Contratar serviço</button>
    </form>

    <button class="botao" onclick="location.href='<?= site_url('home') ?>'">⤌</button> 

</body>
</html>
