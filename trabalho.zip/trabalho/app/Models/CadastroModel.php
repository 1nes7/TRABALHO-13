<?php

namespace App\Models;

use CodeIgniter\Model;

class CadastroModel extends Model
{
    protected $table      = 'cadastro';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nome', 'email', 'telefone','cpf', 'senha_hash'];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    public function cadastrar(array $dados)
    {
        return $this->insert($dados);
    }
}


