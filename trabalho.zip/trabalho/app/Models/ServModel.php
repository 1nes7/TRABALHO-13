<?php

namespace App\Models;

use CodeIgniter\Model;

class ServModel extends Model
{
    protected $table = 'servicos'; // Nome da tabela no banco(acho q eu nem fiz)
    protected $primaryKey = 'id';
    protected $allowedFields = ['tipo', 'descricao', 'preco', 'disponivel'];

    
    // public function getServicosDisponiveis()
    
    //     return $this->where('disponivel', true)->findAll();
   
}
