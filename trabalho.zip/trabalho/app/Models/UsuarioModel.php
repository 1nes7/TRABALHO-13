<?php

namespace App\Models;

use CodeIgniter\Model;

class UsuarioModel extends Model
{
    protected $table      = 'cadastro';
    protected $primaryKey = 'id';

    protected $allowedFields = ['nome', 'email','telefone','cpf', 'senha_hash', 'created_at', 'updated_at'];
}


