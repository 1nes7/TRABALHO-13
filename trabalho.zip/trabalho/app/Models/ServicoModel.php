<?php

namespace App\Models;

use CodeIgniter\Model;

class ServicoModel extends Model
{
    protected $table = 'servicos';
    protected $primaryKey = 'id';
    protected $allowedFields = ['tipo', 'data_agendamento', 'usuario_id'];

    public function getServicosAgendados()
    {
        // Dados simulados para testes
        return [
            ['id' => 1, 'tipo' => 'Hospedagem', 'data_agendamento' => '2025-06-15'],
            ['id' => 2, 'tipo' => 'Trilhas', 'data_agendamento' => null],
            ['id' => 3, 'tipo' => 'Guias', 'data_agendamento' => '2025-07-01'],
        ];
    }
}
