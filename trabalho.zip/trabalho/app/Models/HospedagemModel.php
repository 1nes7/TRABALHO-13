<?php

namespace App\Models;

use CodeIgniter\Model;

class HospedagemModel extends Model
{
    protected $table = 'hospedagens'; // rpz vou ver ainda (array estatico)
    protected $primaryKey = 'id';
    protected $allowedFields = ['nome', 'pais', 'cidade', 'descricao'];

   
    public function getHospedagens()
    {
        return [
            [
                'id' => 1,
                'nome' => 'Hotel Sonata de Iracema',
                'pais' => 'Brasil',
                'cidade' => 'Fortaleza',
                'descricao' => 'Práticas sustentáveis como uso de energia solar e valorização da cultura local.'
            ],
            [
                'id' => 2,
                'nome' => 'Villa Park Hotel',
                'pais' => 'Brasil',
                'cidade' => 'Fortaleza',
                'descricao' => 'Utiliza energia renovável, lâmpadas LED e canudos biodegradáveis.'
            ],
            [
                'id' => 3,
                'nome' => 'Hotel Lisboa Verde',
                'pais' => 'Portugal',
                'cidade' => 'Lisboa',
                'descricao' => 'Hotel sustentável com práticas ecológicas em Lisboa.'
            ],
            [
                'id' => 4,
                'nome' => 'Porto Eco Inn',
                'pais' => 'Portugal',
                'cidade' => 'Porto',
                'descricao' => 'Eco hotel em Porto com foco em preservação ambiental.'
            ],
            [
                'id' => 5,
                'nome' => 'Barcelona Eco Stay',
                'pais' => 'Espanha',
                'cidade' => 'Barcelona',
                'descricao' => 'Sustentabilidade e conforto no coração de Barcelona.'
            ],
        ];
    }

    public function getPaises()
    {
        
        $hoteis = $this->getHospedagens();
        $paises = array_unique(array_column($hoteis, 'pais'));
        sort($paises);
        return $paises;
    }

    public function getCidadesPorPais($pais)
    {
        $hoteis = $this->getHospedagens();
        $cidades = [];
        foreach ($hoteis as $hotel) {
            if ($hotel['pais'] === $pais) {
                $cidades[] = $hotel['cidade'];
            }
        }
        $cidades = array_unique($cidades);
        sort($cidades);
        return $cidades;
    }
}
