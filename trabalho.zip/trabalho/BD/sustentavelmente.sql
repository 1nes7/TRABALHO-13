-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 10-Jun-2025 às 21:13
-- Versão do servidor: 10.4.22-MariaDB
-- versão do PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `sustentavelmente`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `agendamentos_trilhas`
--

CREATE TABLE `agendamentos_trilhas` (
  `id` int(11) NOT NULL,
  `lugar` varchar(255) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `data` date NOT NULL,
  `quantidade` int(11) NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `agendamentos_trilhas`
--

INSERT INTO `agendamentos_trilhas` (`id`, `lugar`, `nome`, `data`, `quantidade`, `criado_em`) VALUES
(1, 'Trilha da Pedra Furada', 'jmnjkl', '2009-03-12', 4, '2025-06-03 18:42:20'),
(2, 'Sendero Fitz Roy', 'hedenn', '2025-04-12', 2, '2025-06-10 18:28:23');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cadastro`
--

CREATE TABLE `cadastro` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `cpf` varchar(14) NOT NULL,
  `senha_hash` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `cadastro`
--

INSERT INTO `cadastro` (`id`, `nome`, `email`, `telefone`, `cpf`, `senha_hash`, `created_at`, `updated_at`, `foto`) VALUES
(1, 'sdcasc', 'herobrinegamer@gmail.com', NULL, '76552637484', '$2y$10$xioVElr5mpoR3VxALIsRNOaDExlF5QvtDkJ0IZdtrZ1zXy7X2h.Xm', '2025-05-23 18:44:12', '2025-05-23 18:44:12', NULL),
(2, 'Ines Martins de Morais', 'inesmartins@gmail.com', NULL, '12345678901', '$2y$10$xV2dONrui9RtawUDBuFsDuD84oWASEE5KvFwHP9V2FrSjuvnBKkOS', '2025-05-30 19:28:59', '2025-05-30 19:28:59', NULL),
(4, 'ines', 'inesmartins12@gmail.com', '859934567', '', '$2y$10$KmUZJVLbtDQdienzaWv5m.Yq31mgMUtLMLlmb2h5fOGpUyp7a5Npi', '2025-06-10 18:14:38', '2025-06-10 16:04:15', '1749581503_001a0fedf8c6fe369310.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `guias_contratados`
--

CREATE TABLE `guias_contratados` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `destino` varchar(150) NOT NULL,
  `guia_particular` tinyint(1) DEFAULT 0,
  `trilha` tinyint(1) DEFAULT 0,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `guias_contratados`
--

INSERT INTO `guias_contratados` (`id`, `nome`, `quantidade`, `destino`, `guia_particular`, `trilha`, `criado_em`) VALUES
(1, 'ines', 1, 'xique xique bahia', 1, 0, '2025-06-03 18:52:48'),
(2, 'ines', 2, 'Serra da Canastra', 1, 0, '2025-06-10 18:20:02');

-- --------------------------------------------------------

--
-- Estrutura da tabela `reservas`
--

CREATE TABLE `reservas` (
  `id` int(11) NOT NULL,
  `hotel` varchar(100) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `reservas`
--

INSERT INTO `reservas` (`id`, `hotel`, `nome`, `quantidade`, `preco`, `criado_em`) VALUES
(1, 'EcoHotel Verde Vida', 'ines', 5, '250.00', '2025-06-03 22:23:18'),
(2, 'EcoHotel Verde Vida', 'ines', 5, '250.00', '2025-06-03 22:24:47'),
(3, 'EcoHotel Verde Vida', 'ines', 5, '250.00', '2025-06-03 22:27:44'),
(4, 'EcoHotel Verde Vida', 'ines', 5, '250.00', '2025-06-03 22:29:40');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `agendamentos_trilhas`
--
ALTER TABLE `agendamentos_trilhas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `cadastro`
--
ALTER TABLE `cadastro`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `cpf` (`cpf`);

--
-- Índices para tabela `guias_contratados`
--
ALTER TABLE `guias_contratados`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `agendamentos_trilhas`
--
ALTER TABLE `agendamentos_trilhas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `cadastro`
--
ALTER TABLE `cadastro`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `guias_contratados`
--
ALTER TABLE `guias_contratados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `reservas`
--
ALTER TABLE `reservas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
