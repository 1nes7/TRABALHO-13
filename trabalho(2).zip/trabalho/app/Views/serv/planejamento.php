
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Planejamento Financeiro</title>
    <style>

body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f4;
    color: #333;
    margin: 0;
    padding: 0;
}

h2 {
    text-align: center;
    color: #2c6e49;
    font-size: 2rem;
    margin-top: 20px;
}


form {
    max-width: 600px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}


label {
    display: block;
    font-weight: bold;
    margin-bottom: 8px;
    color: #2c6e49;
}


input[type="number"],
input[type="checkbox"] {
    width: 100%;
    padding: 10px;
    margin: 8px 0 20px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}


button[type="submit"] {
    background-color:rgb(74, 143, 102);
    color: white;
    border: none;
    padding: 12px 20px;
    font-size: 1rem;
    border-radius: 4px;
    cursor: pointer;
    width: 100%;
    transition: background-color 0.3s ease;
}

button[type="submit"]:hover {
    background-color: #1e4d36;
}


h3 {
    text-align: center;
    color:rgb(74, 143, 102);
    font-size: 1.5rem;
    margin-top: 20px;
}
 .botao {
            width: 90px;
            height: 80px;
            margin-left: 50px;
            color: white;
            background-color:rgb(74, 143, 102);
            font-size: 39px;
        }


    </style>
</head>
<body>
    <h2>Planejamento Financeiro</h2>

    <form action="<?= site_url('planejamento/calcular') ?>" method="post">
        <?= csrf_field() ?>

        <label for="quantidade_pessoas">Quantidade de Pessoas:</label>
        <input type="number" name="quantidade_pessoas" id="quantidade_pessoas" required>

        <label for="hospedagem">Hospedagem (R$150 por pessoa/dia):</label>
        <input type="checkbox" name="hospedagem" value="1">

        <label for="trilhas">Trilhas (R$70 por pessoa):</label>
        <input type="checkbox" name="trilhas" value="1">

        <label for="lojas_locais">Visitar Lojas Locais (R$200 por pessoa):</label>
        <input type="checkbox" name="lojas_locais" value="1">

        <label for="guia_particular">Guia Particular (R$200 por pessoa):</label>
        <input type="checkbox" name="guia_particular" value="1">

        <button type="submit">Calcular</button>
    </form>

    <?php if (isset($total)): ?>
        <h3>Total Estimado: R$ <?= number_format($total, 2, ',', '.') ?></h3>
    <?php endif; ?>

      <button class="botao" onclick="location.href='<?= site_url('home') ?>'">⤌</button> 
</body>
</html>
