<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Hospedagens Sustentáveis - Sustentavelmente</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f1f7f1;
            margin: 20px;
            color: #2e7d32;
        }
        h1 {
            text-align: center;
            margin-bottom: 30px;
        }
        .filtros {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 30px;
        }
        select {
            padding: 8px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }
        .hotel-card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin: 20px auto;
            max-width: 700px;
            box-shadow: 0 0 10px rgba(0,0,0,0.08);
        }
        .hotel-card h3 {
            margin-top: 0;
        }
        .hotel-card p {
            margin: 8px 0;
        }
        .btn-reservar {
            background-color: #4caf50;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 6px;
            display: inline-block;
            margin-top: 10px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }
        .btn-reservar:hover {
            background-color: #357a38;
        }
        .botao {
            width: 90px;
            height: 80px;
            margin-left: 50px;
            color: white;
            background-color:rgb(74, 143, 102);
            font-size: 39px;
        }
    </style>
</head>
<body>

    <h1>Hospedagens Sustentáveis</h1>

    <!-- Filtro igual ao das trilhas -->
    <form method="get" class="filtros">
        <select name="pais" onchange="this.form.submit()">
            <option value="">-- Selecione o país --</option>
            <?php foreach ($paises as $pais): ?>
                <option value="<?= esc($pais) ?>" <?= ($pais == $paisFiltro) ? 'selected' : '' ?>><?= esc($pais) ?></option>
            <?php endforeach; ?>
        </select>

        <select name="cidade" onchange="this.form.submit()" <?= empty($cidades) ? 'disabled' : '' ?>>
            <option value="">-- Selecione a cidade --</option>
            <?php foreach ($cidades as $cidade): ?>
                <option value="<?= esc($cidade) ?>" <?= ($cidade == $cidadeFiltro) ? 'selected' : '' ?>><?= esc($cidade) ?></option>
            <?php endforeach; ?>
        </select>
    </form>

    <?php if (empty($hoteis)): ?>
        <p style="text-align:center;">Nenhum hotel encontrado para os filtros selecionados.</p>
    <?php endif; ?>

    <?php foreach ($hoteis as $hotel): ?>
        <div class="hotel-card">
            <h3><?= esc($hotel['nome']) ?></h3>
            <p><strong>País:</strong> <?= esc($hotel['pais']) ?></p>
            <p><strong>Cidade:</strong> <?= esc($hotel['cidade']) ?></p>
            <p><?= esc($hotel['descricao']) ?></p>
            <a href="<?= site_url('hospedagemform')?>" class="btn-reservar">Reservar</a>
        </div>
    <?php endforeach; ?>

    <button class="botao" onclick="location.href='<?= site_url('home') ?>'">⤌</button> 
</body>
</html>
