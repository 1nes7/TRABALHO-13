<?php

namespace App\Controllers;

use App\Models\ServModel;
use CodeIgniter\Controller;

class Serv extends BaseController
{
    public function index()
    {
        // se futuramente eu queira passar dados do model:
        $model = new ServModel();

       
      return view('serv/serv');

    }
}
